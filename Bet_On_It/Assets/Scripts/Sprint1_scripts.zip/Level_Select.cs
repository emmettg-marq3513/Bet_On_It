﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level_Select : MonoBehaviour
{
    /*
    public void Level_0()
    {
        SceneManager.LoadScene(/*Build index of Tutorial/);
    }
    public void Level_1()
    {
        SceneManager.LoadScene(/*Build index of Tutorial/);
    }
    public void Level_2()
    {
        SceneManager.LoadScene(/*Build index of Tutorial/);
    }
    */
}
